<?php
/*
$dbh = mysql_connect("localhost", "root", "Ccas1992");
$db = mysql_select_db("promo");
*/
include("../class.conexion.php");  
 $db = new conn();  
 
?>

<table width="100%" >
			<tr bgcolor="gray" >
				<td><font face="Verdana" size="3" ><b><i>Evento</i></b></font></td>
				<td><font face="Verdana" size="3" ><b><i>Fechas Inscripciones</i></b></font></td>
				<td><font face="Verdana" size="3" ><b><i>Fecha Evento</i></b></font></td>
				<td><font face="Verdana" size="3" ><b><i>Hora Evento</i></b></font></td>
				<td><font face="Verdana" size="3" ><b><i>Inscripciones</i></b></font></td>
				<td><font face="Verdana" size="3" ><b><i>Ver</i></b></font></td>
			</tr>
		<?php
		$sql2=$db->consulta("select nom_evento,fec_inicio,fec_fin,fec_event,hora,idevento from evento where estado='ACTIVO' order by idevento  ;");
		$numr=$db->num_rows($sql2);
		
		
		while($row2=$db->fetch_array($sql2)){
		$sql3=$db->consulta("select count(cedula) as 'CANT' from event_asist where idevent=$row2[idevento] ");
		$row=$db->fetch_array($sql3);
		if($numr%2 == 1){
		
			echo "<tr bgcolor=silver align=center >
				<td><font face=Verdana size=2 ><b><i>$row2[nom_evento]</i></b></font></td>
				<td><font face=Verdana size=2 ><b><i>$row2[fec_inicio]/$row2[fec_fin]</i></b></font></td>
				<td><font face=Verdana size=2 ><b><i>$row2[fec_event]</i></b></font></td>
				<td><font face=Verdana size=2 ><b><i>$row2[hora]</i></b></font></td>
				<td><font face=Verdana size=2 ><b><i>$row[CANT]</i></b></font></td>
				<td><a href=./informes/inscrip_excel.php?cod=$row2[idevento] ><img src='./img/excel.png' width=30 /></a></td>
				</tr>";
			}else{
			echo "<tr align=center >
				<td><font face=Verdana size=2 ><b><i>$row2[nom_evento]</i></b></font></td>
				<td><font face=Verdana size=2 ><b><i>$row2[fec_inicio]/$row2[fec_fin]</i></b></font></td>
				<td><font face=Verdana size=2 ><b><i>$row2[fec_event]</i></b></font></td>
				<td><font face=Verdana size=2 ><b><i>$row2[hora]</i></b></font></td>
				<td><font face=Verdana size=2 ><b><i>$row[CANT]</i></b></font></td>
				<td><a href=./informes/inscrip_excel.php?cod=$row2[idevento] ><img src='./img/excel.png' width=30 /></a></td>
				</tr>";
			
			}
			$numr-=1;
		}
		
		?>
		</table>
		
				
