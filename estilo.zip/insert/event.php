<?php
/*
$conexion = mysql_connect("localhost", "root", "Ccas1992");
mysql_select_db("promo", $conexion);
*/

include("../class.conexion.php");

$db = new conn();

$sw=0;

if($_POST[namevent] != null && $_POST[finicio] != null && $_POST[fcierre] != null && $_POST[cupo] != null){
$event = utf8_decode($_POST[namevent]);
$consulta = $db->consulta("insert into evento (nom_evento,fec_event,fec_inicio,fec_fin,hora,lugar,estado,image,cupo) values ('$event','$_POST[fecevent]','$_POST[finicio]','$_POST[fcierre]','$_POST[hevent]','$_POST[lugar]','ACTIVO','$_POST[list]',$_POST[cupo]);");

$sqlmax = $db->consulta("SELECT max(idevento) as idevent FROM `evento` order by idevento desc ;");
  $row = $db->fetch_array($sqlmax);
$sw=1;

}


if($sw == 1){
$array = array ( "enviar" => 1 , "capa" => "$row[idevent]" );
$arrayj = json_encode($array);
echo $arrayj;
}else{
$array = array ( "enviar" => 2 , "capa" => 2 );
$arrayj = json_encode($array);
echo $arrayj;
}



$db->cerrar();
//mysql_close($conexion);

?>