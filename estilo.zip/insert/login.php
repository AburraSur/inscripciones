<?php

/*
$conexion = mysql_connect("localhost", "root", "Ccas1992");
mysql_select_db("promo", $conexion);
*/

include("../class.conexion.php");  
 $db = new conn();  
  $consulta = $db->consulta("SELECT * FROM usuario;");  
  $sw=0;
    $user=$_POST['user'];
$pass=$_POST['pass'];
  while($resultados = $db->fetch_array($consulta)){  
	if($resultados['user']==$user && $resultados['pass']==$pass && $resultados['estado']=='ACTIVO' ){
		$codigo= $resultados['iduser'];
		$ubica= $resultados['ubicacion'];
		session_start ();
		$_SESSION['iduser']=$codigo;
		$_SESSION['ubicacion']=$ubica;

		$sw=1;
		}
  }  
/*  
$sw=0;



$user=$_POST['user'];
$pass=$_POST['pass'];

if($user != null && $pass != null ){

$result=mysql_query("SELECT * FROM usuario;");

 while($sql = mysql_fetch_array($result)) { 
		if($sql['user']==$user && $sql['pass']==$pass && $sql['estado']=='ACTIVO' ){
		$codigo= $sql['iduser'];
		$ubica= $sql['ubicacion'];
		session_start ();
		$_SESSION['iduser']=$codigo;
		$_SESSION['ubicacion']=$ubica;

		$sw=1;
		}
	
	}


}
*/

if($sw == 1){
$array = array ( "enviar" => 1 );
$arrayj = json_encode($array);
echo $arrayj;
}else{
$array = array ( "enviar" => 2 );
$arrayj = json_encode($array);
echo $arrayj;
}

$db->cerrar();  
//mysql_close($conexion);

?>