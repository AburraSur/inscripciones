<?php
/*
$conexion = mysql_connect("localhost", "root", "Ccas1992");
mysql_select_db("promo", $conexion);

include("../class.conexion.php");  
 $db = new conn();  
  
$sw=0;

if($_POST[docid] != null && $_POST[nombres] != null  && $_POST[apellidos] != null && $_POST[tel] != null && $_POST[nit] != null && $_POST[nomemp] != null){

$consulta = $db->consulta("insert into asistentes (cedula,nom1,ape1,email,tel,cel,dir,municipio,nit,nom_empresa,dir_empresa,cargo,afiliado,comentario,idevento) values ('$_POST[docid]','$_POST[nombres]','$_POST[apellidos]','$_POST[mail]','$_POST[tel]','$_POST[cel]','$_POST[dir]','$_POST[muni]','$_POST[nit]','$_POST[nomemp]','$_POST[diremp]','$_POST[cargo]','$_POST[afili]','$_POST[coment]',$_POST[idevent])  ;");  
  
/*  
mysql_query("insert into asistentes (cedula,nom1,nom2,ape1,ape2,email,tel,cel,dir,municipio,nit,nom_empresa,dir_empresa,cargo,afiliado,comentario,idevento) values ('$_POST[docid]','$_POST[firstname]','$_POST[secname]','$_POST[firstape]','$_POST[secape]','$_POST[mail]','$_POST[tel]','$_POST[cel]','$_POST[dir]','$_POST[muni]','$_POST[nit]','$_POST[nomemp]','$_POST[diremp]','$_POST[cargo]','$_POST[afili]','$_POST[coment]',$_POST[idevent]) ");

$sw=1;

}


if($sw == 1){
$array = array ( "enviar" => 1 );
$arrayj = json_encode($array);
echo $arrayj;
}else{
$array = array ( "enviar" => 2 );
$arrayj = json_encode($array);
echo $arrayj;
}

$db->cerrar(); 
//mysql_close($conexion);
*/

$mail=$_POST["idevent"];
include("../class.conexion.php");  
 $db = new conn();  
  $consulta = $db->consulta("select * from evento where idevento=$mail ;");  
  $row=$db->fetch_array($consulta);
  
$correo="<p style='font-family:Arial;font-size:12px;line-height:16px;align:justify'>Se�or Usuario, gracias por registrase en el evento $row[nom_evento],
programado para el d�a $row[fec_inicio] a las $row[hora] en el $row[lugar].
<br>
Si el evento al que se ha inscrito tiene costo, una de las Asesoras
Empresariales de la C�mara de Comercio Aburr� Sur le contactar� para verificar
los datos relacionados con el pago de su inscripci�n.
<br>
Recuerde estar en el sitio del evento 15 minutos antes de su inicio.
<br>
Tenga en cuenta que en nuestro Centro de Convenciones tenemos a su disposici�n
el servicio de Parqueadero Cubierto administrado por CORPAUL.</p><br><img src=../uploads/$row[image] />";
	require_once('class.phpmailer.php');
	$i = 1;
	
	
	$mail = new PHPMailer();
	$mail->IsSMTP();
	$mail->SMTPAuth = true;
	$mail->SMTPSecure = "tls";
	$mail->Host       = "192.168.1.20";
	$mail->Port       = 25;
	$mail->Username = "inscripciones@ccas.org.co";
	$mail->Password = "ccas2010";
	$body = "<html><head><style>p{font-family:Arial;font-size:12px}</style></head><body>$correo</body>";
	$mail->SetFrom("inscripciones@ccas.org.co","Inscripciones");
	while($i <= $_POST["ctrl"]){
	$mailing=$_POST["mail$i"];
	$nom=$_POST["nombres$i"];
	$ape=$_POST["apellidos$i"];
		$mail->AddAddress("$mailing", "$nom $ape");
		
	$i+=1;
	}
	//$mail->AddAddress("inscripciones@ccas.org.co", "Inscripciones");
	//$mail->AddAttachment("./file.pdf", "file.pdf");
	$mail->Subject = "Inscripciones Evento:";
	$mail->MsgHTML($body);
	$mail->Send();
	

$array = array ( "enviar" => 1 );
$arrayj = json_encode($array);
echo $arrayj;



?>