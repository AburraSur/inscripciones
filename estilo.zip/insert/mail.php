<?php

$mail=$_GET[cod];
/*
$conexion = mysql_connect("localhost", "root", "Ccas1992");
mysql_select_db("promo", $conexion);

$sql=mysql_query("select * from evento where idevento=$mail ");
$row=mysql_fetch_array($sql);


mysql_close($conexion);
*/

include("../class.conexion.php");  
 $db = new conn();  
  $consulta = $db->consulta("select * from evento where idevento=$mail ;");  
  $row=$db->fetch_array($consulta);
  
$correo="<p style='font-family:Arial;font-size:12px;line-height:16px;'>
	<center><strong>INFORMACION DEL EVENTO</strong></center><br /><br />
	<strong>Nombre del Evento: </strong> $row[nom_evento]<br /><br />
	<strong>Fecha Inicio de Inscripciones:</strong> $row[fec_inicio]<br /><br />
	<strong>Fecha Cierre de Inscripciones:</strong> $row[fec_fin]<br /><br />
	<strong>Link del Formulario de Inscripcion:</strong> http://192.168.1.32/tools/activos/promocion/maestro/confor3.php?cod=$mail<br /><br />";
	require_once('class.phpmailer.php');
	$mail = new PHPMailer();
	$mail->IsSMTP();
	$mail->SMTPAuth = true;
	$mail->SMTPSecure = "tls";
	$mail->Host       = "192.168.1.20";
	$mail->Port       = 25;
	$mail->Username = "inscripciones@ccas.org.co";
	$mail->Password = "ccas2010";
	$body = "<html><head><style>p{font-family:Arial;font-size:12px}</style></head><body>$correo</body>";
	$mail->SetFrom("inscripciones@ccas.org.co","Inscripciones");
	//$mail->AddAddress("carloshoyos@ccas.org.co", "Carlos Hoyos");
	$mail->AddAddress("inscripciones@ccas.org.co", "Inscripciones");
	//$mail->AddAttachment("./file.pdf", "file.pdf");
	$mail->Subject = "Inscripciones Evento:";
	$mail->MsgHTML($body);
	$mail->Send();



?>