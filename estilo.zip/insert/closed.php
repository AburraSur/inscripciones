<?php
/*
$conexion = mysql_connect("localhost", "root", "Ccas1992");
mysql_select_db("promo", $conexion);
*/

include("../class.conexion.php");
$db = new conn();


$sw=0;

$sql=$db->consulta("select nom_evento from evento where idevento=$_POST[closed] ;");
$row=$db->fetch_array($sql);

if($_POST[closed] != null){

$db->consulta("update evento set estado='CERRADO' where idevento=$_POST[closed] ;");
$sw=1;

}



if($sw == 1){
$array = array ( "enviar" => 1 , "capa" => "$row[nom_evento]" );
$arrayj = json_encode($array);
echo $arrayj;
}else{
$array = array ( "enviar" => 2 , "capa" => "$row[nom_evento]" );
$arrayj = json_encode($array);
echo $arrayj;
}

mysql_close($conexion);

?>