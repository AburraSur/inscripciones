<?php
@mysql_query("SET NAMES 'utf8_decode'");

include("../class.conexion.php");  
 $db = new conn();  


$numins = 0;
$idev=$_POST["idevent"];
$ctrl=$_POST["ctrl"];
$ctrl2=0;
$empl="";
$nit="$_POST[nit]-$_POST[dv]";

  $consulta = $db->consulta("SELECT * FROM event_asist ea INNER JOIN asistentes a WHERE ea.cedula = a.cedula AND a.nit = '$nit' ;");  
$inscritos="";
  while($row=$db->fetch_array($consulta)){
	$inscritos.= " $row[nombres] $row[apellidos]";
	$numins += 1; 
  }
  
 
  
    $sql = $db->consulta("select cupo from evento where idevento=$idev ");
	$rowsql = $db->fetch_array($sql);
	
	 $dispc = ( $rowsql['cupo'] - $numins );
	 
if( $dispc >= $ctrl){
if($numins < $rowsql['cupo'] ){
	for($j=1;$j<=$ctrl;$j++){
	$ced=$_POST["docid$j"];
	$nombres=$_POST["nombres$j"];
	$apellidos=$_POST["apellidos$j"];
		$registro = $db->consulta("select * from event_asist where idevent=$idev and cedula='$ced' ");
		$numrows = $db->num_rows($registro);
		if($numrows > 0){$empl.="$nombres $apellidos, ";}
	}
	
	if($numrows == 0){
		for($i = 1;$i <= $ctrl;$i++){
		if($_POST["docid$i"] != null && $_POST["nombres$i"] != null  && $_POST["apellidos$i"] != null && $_POST["tel$i"] != null && $nit != null && $_POST["dv"] != null && $_POST["nomemp"] != null){
			$ctrl2+=1;
		}
		}
		if($ctrl2 == $ctrl){
		
			$regempresa = $db->consulta("select * from empresa where nit='$nit' ");
			$yaregempre = $db->num_rows($regempresa);
			
			if($yaregempre == 0){
				$empresa = $db->consulta("insert into empresa (nit,rsocial,dir,comentario) values ('$nit','$_POST[nomemp]','$_POST[diremp]','$_POST[coment]')");
			}
			
			for($k=1;$k<=$ctrl;$k++){
			$ced=$_POST["docid$k"];
			$nombres=$_POST["nombres$k"];
			$apellidos=$_POST["apellidos$k"];
			$mailx=$_POST["mail$k"];
			$tel=$_POST["tel$k"];
			$cel=$_POST["cel$k"];
			$muni=$_POST["muni$k"];
			$cargo=$_POST["cargo$k"];
			
				$reg = $db->consulta("select * from asistentes where cedula='$ced' and nit='$nit' ");
				$yaregistra = $db->num_rows($reg);
				if($yaregistra == 0){
				$asist = $db->consulta("insert into asistentes (cedula,nombres,apellidos,email,tel,cel,municipio,nit,cargo) values ('$ced','$nombres','$apellidos','$mailx','$tel','$cel','$muni','$nit','$cargo')");
				}
				$eventasis= $db->consulta("insert into event_asist (idevent,cedula) values ($idev,'$ced')");
			}
			
			//bloque de envio de correo a inscritos
			
				$consultamail = $db->consulta("select * from evento where idevento=$idev ;");  
				$rowmail=$db->fetch_array($consultamail);
  
				$correo="<p style='font-family:Arial;font-size:12px;line-height:16px;align:justify'>Se�or Usuario, gracias por registrase en el evento $rowmail[nom_evento], programado para el d�a $rowmail[fec_event] a las $rowmail[hora] en el $rowmail[lugar].
<br><br>
Si el evento al que se ha inscrito tiene costo, una de las Asesoras Empresariales de la C�mara de Comercio Aburr� Sur le contactar� para verificar los datos relacionados con el pago de su inscripci�n.
<br><br>
Recuerde estar en el sitio del evento 15 minutos antes de su inicio.
<br>
Tenga en cuenta que en nuestro Centro de Convenciones tenemos a su disposici�n el servicio de Parqueadero Cubierto administrado por CORPAUL.
</p>";
							
				require_once('./class.phpmailer.php');
					$i = 1;
	
	
					$mail = new PHPMailer();
					$mail->IsSMTP();
					$mail->SMTPAuth = true;
					$mail->SMTPSecure = "tls";
					$mail->Host       = "192.168.1.20";
					$mail->Port       = 25;
					$mail->Username = "inscripciones@ccas.org.co";
					$mail->Password = "ccas2010";
					$body = "<html><head><style>p{font-family:Arial;font-size:12px}</style></head><body>$correo</body>";
					$mail->SetFrom("inscripciones@ccas.org.co","Inscripciones");
					while($i <= $_POST["ctrl"]){
						$mailing=$_POST["mail$i"];
						$nom=$_POST["nombres$i"];
						$ape=$_POST["apellidos$i"];
						$compl="$nom $ape";
						$mail->AddAddress("$mailing", "$compl");
		
						$i+=1;
					}
					//$mail->AddAddress("inscripciones@ccas.org.co", "Inscripciones");
					$mail->AddAttachment("../uploads/$rowmail[image]", "$rowmail[image]");
					$mail->Subject = "Inscripciones Evento:";
					$mail->MsgHTML($body);
					$mail->Send();
	
				$sw=1;
			
		}else{
			$sw=2;
			$mensaje="Los datos son incorrectos, por favor verificarlos.";
		}
	
	}else{
		$sw=2;
		$mensaje="Los usuarios $empl ya estan registrados para este evento.";
	}
}else{
		$sw=2;
		$mensaje="Usted ya realizo la inscripcion de los siguientes usuarios:<br> $inscritos ";
}
}else{
		$sw=2;
		if($dispc == 0){
			$mensaje="Usted ya registro los cupos disponibles para este evento ";
		}else{
			$mensaje="Usted solo tiene $dispc cupos disponibles ";
		}
}

/*$array = array ( "enviar" => $sw , "mensaje" => $mensaje );
$arrayj = json_encode($array);
echo $arrayj;*/

echo "<script src=../js/jquery-1.4.2.min.js ></script>
<script src='../js/jquery.blockUI-validate.js'></script>
<script type='text/javascript' src='js/jquery-1.4.2.js'></script>
<script  language='JavaScript' type='text/javascript'> 
  $(document).ready(function(){
  if($sw == 1){
			
			$.blockUI({ message: '<h3><img src=../img/check2.png width=50 height=50 />Inscripci�n Exitosa.<br>Un correo de confirmaci�n ha sido enviado<br>a cada una de las personas inscritas!</h3><br><input type=image src=../img/salir.png id=salida />' });
				
				
				$('#salida').click(function(){
				
					$('#form1').each (function(){
					this.reset();
					$('#boton').remove();
					
					})
					
					window.location='http://www.ccas.org.co';
					
				});
				
				
			}
			if($sw == 2){
			$.blockUI({ message: '<h3><img src=../img/bad.png /><br>$mensaje.</h3><br><input type=image src=../img/salir.png id=salida />' });
			
			$('#salida').click(function(){
				
					
					window.location='./confor.php?cod=$idev ';
					
				});
			
			}
				
				});
	
	
 </script> 
 </head>

	<body background=../img/bg2.jpg ></body>";

?>