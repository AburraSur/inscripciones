
<html>
<head><title>Inscripciones</title>
<link rel="icon" type="image/gif" href="../img/shopping.ico" /> 
 <LINK href="../estilo/divestilo.css" rel="stylesheet" type="text/css">
<LINK href="../estilo/button.css" rel="stylesheet" type="text/css">
<script src="../js/jquery-1.4.2.min.js"></script>
<script src="../js/jquery.blockUI-validate.js"></script>
<script type="text/javascript" src="js/jquery-1.4.2.js"></script>

</head>

	<body background="../img/bg2.jpg" >
		<table width="85%" height="100%" align="center"  >
		<tr>
			<td>
				<div> 
				<b class="spiffy"> 
				<b class="spiffy1"><b></b></b>
				<b class="spiffy2"><b></b></b>
				<b class="spiffy3"></b>
				<b class="spiffy4"></b>
				<b class="spiffy5"></b> 
				</b> <div class="spiffy_content">
<fieldset>

			<table width="100%" align="center">
		<tr>
			<td>
				<center>
							
				</center>			
			</td>
		</tr>
		<tr>
			<td>
				<center>
					
								
				</center>			
			</td>
		</tr>		
		
		<tr>
			<td>
				<center>
					<font face=Verdana size=6  ><b><i>Las Inscripciones para este Evento<br>se Encuentran Cerradas</i></b></font>
							
				</center>			
			</td>
		</tr>
		<tr>
			<td>
				<center>
					<a href="http://www.ccas.org.co" ><img src="../img/exit.png" /><br><font face=Verdana size=2  ><b><i>Salir</i></b></font></a>			
				</center>			
			</td>
		</tr>

	<table  align="center" id="tcenter" >
				
		<tr>
			<td>
				<center>
						
				</center>			
			</td>
		</tr>
		<tr>
			<td>
				<table width="100%" >
					<tr><td align="left" ><font size="2" color="red" ><i><b>Los campos marcados con * son obligatorios</b></i></font></td><td align="right" ><a href="#" id="logout" ><b><i>Salida Segura</i></b><img src="../img/logout.png" /></a>		</td></tr></table>
			</td>
		</tr>
		
				 
				
		<tr>
			<td>
				
				
				<form id="form1" action="./tilde.php" method="POST" >
				
				<input type="text" name="uno" />
				<input type="text" name="dos" />
				<input type="text" name="tres" />
					
					<center><input type="image" src="../img/button-1.png" id="boton" /></center>
				</form>
			

	</body>

</html>